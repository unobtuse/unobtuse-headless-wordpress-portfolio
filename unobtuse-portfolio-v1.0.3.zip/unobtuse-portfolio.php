<?php
/**
 * Plugin Name: Unobtuse Portfolio
 * Plugin URI: https://github.com/unobtuse/unobtuse-headless-wordpress-portfolio
 * Description: Custom post types, taxonomies, and fields for Unobtuse headless WordPress portfolio site. Integrates with WPGraphQL for headless frontend.
 * Version: 1.0.0
 * Author: Gabriel - Unobtuse
 * Author URI: https://unobtuse.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: unobtuse-portfolio
 * Domain Path: /languages
 * Requires at least: 6.0
 * Tested up to: 6.4
 * Requires PHP: 8.0
 * Network: false
 * 
 * @package UnobtusePo
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('UNOBTUSE_PORTFOLIO_VERSION', '1.0.0');
define('UNOBTUSE_PORTFOLIO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('UNOBTUSE_PORTFOLIO_PLUGIN_URL', plugin_dir_url(__FILE__));
define('UNOBTUSE_PORTFOLIO_PLUGIN_FILE', __FILE__);

/**
 * Main Plugin Class
 */
class UnobtusePo {
    
    /**
     * Single instance of the class
     * @var UnobtusePo
     */
    private static $instance = null;
    
    /**
     * Get single instance
     * @return UnobtusePo
     */
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->init();
    }
    
    /**
     * Initialize the plugin
     */
    private function init() {
        // Load plugin textdomain
        add_action('plugins_loaded', [$this, 'loadTextdomain']);
        
        // Initialize plugin components
        add_action('init', [$this, 'initializeComponents']);
        
        // Activation/deactivation hooks
        register_activation_hook(__FILE__, [$this, 'activate']);
        register_deactivation_hook(__FILE__, [$this, 'deactivate']);
        
        // Admin notices
        add_action('admin_notices', [$this, 'checkDependencies']);
    }
    
    /**
     * Load plugin text domain
     */
    public function loadTextdomain() {
        load_plugin_textdomain(
            'unobtuse-portfolio',
            false,
            dirname(plugin_basename(__FILE__)) . '/languages/'
        );
    }
    
    /**
     * Initialize plugin components
     */
    public function initializeComponents() {
        // Include required files
        $this->includeFiles();
        
        // Initialize classes
        new UnobtusePo_Post_Types();
        new UnobtusePo_Taxonomies();
        new UnobtusePo_Custom_Fields();
        
        // Initialize WPGraphQL integration if available
        if (function_exists('register_graphql_field')) {
            new UnobtusePo_WPGraphQL_Integration();
        }
    }
    
    /**
     * Include required files
     */
    private function includeFiles() {
        $includes = [
            'includes/class-post-types.php',
            'includes/class-taxonomies.php',
            'includes/class-custom-fields.php',
            'includes/class-wpgraphql-integration.php',
        ];
        
        foreach ($includes as $file) {
            $filepath = UNOBTUSE_PORTFOLIO_PLUGIN_DIR . $file;
            if (file_exists($filepath)) {
                require_once $filepath;
            }
        }
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Initialize components for activation
        $this->includeFiles();
        
        // Create post types and taxonomies
        $post_types = new UnobtusePo_Post_Types();
        $post_types->registerPostTypes();
        
        $taxonomies = new UnobtusePo_Taxonomies();
        $taxonomies->registerTaxonomies();
        
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Set activation flag
        update_option('unobtuse_portfolio_activated', true);
        
        // Clear any existing notices
        delete_transient('unobtuse_portfolio_admin_notices');
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Flush rewrite rules
        flush_rewrite_rules();
        
        // Remove activation flag
        delete_option('unobtuse_portfolio_activated');
        
        // Clear notices
        delete_transient('unobtuse_portfolio_admin_notices');
    }
    
    /**
     * Check plugin dependencies
     */
    public function checkDependencies() {
        $notices = [];
        
        // Check if WPGraphQL is active (recommended)
        if (!class_exists('WPGraphQL')) {
            $notices[] = [
                'type' => 'notice-warning',
                'message' => __('Unobtuse Portfolio: WPGraphQL plugin is recommended for headless functionality. <a href="' . admin_url('plugin-install.php?s=wpgraphql&tab=search&type=term') . '">Install WPGraphQL</a>', 'unobtuse-portfolio')
            ];
        }
        
        // Check WordPress version
        if (version_compare(get_bloginfo('version'), '6.0', '<')) {
            $notices[] = [
                'type' => 'notice-error',
                'message' => __('Unobtuse Portfolio requires WordPress 6.0 or higher. Please update WordPress.', 'unobtuse-portfolio')
            ];
        }
        
        // Check PHP version
        if (version_compare(PHP_VERSION, '8.0', '<')) {
            $notices[] = [
                'type' => 'notice-error',
                'message' => __('Unobtuse Portfolio requires PHP 8.0 or higher. Your PHP version: ' . PHP_VERSION, 'unobtuse-portfolio')
            ];
        }
        
        // Display notices
        foreach ($notices as $notice) {
            printf(
                '<div class="notice %s is-dismissible"><p>%s</p></div>',
                esc_attr($notice['type']),
                wp_kses_post($notice['message'])
            );
        }
    }
    
    /**
     * Get plugin version
     */
    public function getVersion() {
        return UNOBTUSE_PORTFOLIO_VERSION;
    }
}

// Initialize the plugin
UnobtusePo::getInstance(); 